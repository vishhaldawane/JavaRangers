package com.company.strategy1;

import java.util.Iterator;
import java.util.List;

import com.company.BaseDAOImpl;
import org.junit.jupiter.api.Test;


/*
3 ?
2 ?
1 ?

I. "single table" per hierarchy

					BillingDetails (Surgeon)
						|id,owner,number
			------------------------
			|					|
		BankAccount			CreditCard
		bankName			  type,expiryMonth,expiryYear
		(HeartSurgeon)				(NeuroSurgeon)

BankAccount ba1 = new BankAccount(); -> id,owner,number, bankName
BankAccount ba2 = new BankAccount(); -> id,owner,number, bankName
BankAccount ba3 = new BankAccount(); -> id,owner,number, bankName

CreditCard  cc1 = new CreditCard();  -> id,owner,number, type,expiryMonth,expiryYear
CreditCard  cc2 = new CreditCard();  -> id,owner,number, type,expiryMonth,expiryYear

ramji meelan arun piyush
ashish suraj mahmod

		bankdata <-- single table

		<------BankAccount---------> [ 1+2+3+ 4 + + + + 8 ]
		<-BillingDetails->
		1	2		3					<----------CreditCard--------> [ 1+2+3+ +5+6+7+8]
							4			5		6			7			8
																		@DiscriminatorColumn(name="billing_type")
		id	owner	number	bankName	type	expiryMonth	expiryYear	billing_type	maturityMonth	maturityYear	interestRate	dateOfDeposit
		1	Arun	123		ICICI		-		-			-			BA				-				-				-				-
		2   Ramji	445		HDFC		-		-			-			BA				-				-				-				-
		3	Ashish	6575	SC			-		-			-			BA				-				-				-				-

		4	Jack	5567	-			Gold	10			2023		CC				-				-				-				-
		5	Jill	5677	-			Silver	12			2025		CC				-				-				-				-
		6	Arun	4747474	-			-		-			-			FD				July			2028			4.9			12/Oct/2018
 */

public class BillingDetailsTest {
/*
create table BillingDetails1
(
	billing_type varchar(31) not null,
	id integer not null,
	number varchar(255),
	owner varchar(255),
	expiryMonth varchar(255),
	expiryYear varchar(255),
	type varchar(255),
	bankName varchar(255),
	primary key (id)
)


 */
	@Test
	public void testCase1() {
		
		BankAccount bankAcc = new BankAccount();
		bankAcc.setOwner("Majrul Ansari");
		bankAcc.setNumber("12345");
		bankAcc.setBankName("ICICI Bank");

		CreditCard creditCard = new CreditCard();
		creditCard.setOwner("Majrul Ansari");
		creditCard.setNumber("412901234567890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2025");
		
		BaseDAOImpl dao = new BaseDAOImpl();
		dao.mergeAnyObject(bankAcc);
		dao.mergeAnyObject(creditCard);
		
	}

	@Test
	public void testCase2() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<BillingDetails> list = dao.getAll("BillingDetails1");
		System.out.println(list);

		Iterator<BillingDetails> listIterator = list.iterator(); //get iterator for Surgeon

		while(listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			BillingDetails billingDetails = listIterator.next(); //pickup the first surgeon

			if(billingDetails instanceof BankAccount) { //find if it is HeartSurgeon
				BankAccount bankAccount = (BankAccount) billingDetails;
				System.out.println("Bank Id     : "+bankAccount.getId());
				System.out.println("Bank Owner  : "+bankAccount.getOwner());
				System.out.println("Bank Number : "+bankAccount.getNumber());
				System.out.println("Bank Name   : "+bankAccount.getBankName());
			}
			else if (billingDetails instanceof CreditCard) {
				CreditCard creditCard = (CreditCard) billingDetails;
				System.out.println("Bank Id     : "+creditCard.getId());
				System.out.println("Bank Owner  : "+creditCard.getOwner());
				System.out.println("Bank Number : "+creditCard.getNumber());
				System.out.println("Card Type   : "+creditCard.getType());
				System.out.println("Expiry Month: "+creditCard.getExpiryMonth());
				System.out.println("Expiry Year : "+creditCard.getExpiryYear());
			}
			System.out.println("------------------");
		}

	}
}
