package com.company.strategy4;

import java.util.Iterator;
import java.util.List;

import com.company.BaseDAOImpl;
import org.junit.jupiter.api.Test;


public class BillingDetailsTest {


	@Test
	public void testCase1() {

		BillingDetails billingDetails = new BillingDetails();
		billingDetails.setNumber("444");
		billingDetails.setOwner("Julie");



		BankAccount bankAcc = new BankAccount();
		//bankAcc.setId(1);
		bankAcc.setOwner("Arun");
		bankAcc.setNumber("12345");
		bankAcc.setBankName("ICICI Bank");

		CreditCard creditCard = new CreditCard();
		//bankAcc.setId(2);
		creditCard.setOwner("Ramji");
		creditCard.setNumber("412901234567890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2099");

		BaseDAOImpl dao = new BaseDAOImpl();

		dao.mergeAnyObject(billingDetails); //table1
		dao.mergeAnyObject(bankAcc); //table2
		dao.mergeAnyObject(creditCard); //table3
		
	}

	@Test
	public void testCase2() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<BillingDetails> list = dao.getAll("BillingDetails4");
		System.out.println(list);

		Iterator<BillingDetails> listIterator = list.iterator(); //get iterator for Surgeon

		while (listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			BillingDetails billingDetails = listIterator.next(); //pickup the first surgeon

			System.out.println("Bank Id     : " + billingDetails.getId());
			System.out.println("Bank Owner  : " + billingDetails.getOwner());
			System.out.println("Bank Number : " + billingDetails.getNumber());

			System.out.println("--------------");
		}
	}

	@Test
	public void testCase3() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<BankAccount> list = dao.getAll("BankAccount4");
		System.out.println(list);

		Iterator<BankAccount> listIterator = list.iterator(); //get iterator for Surgeon

		while (listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			BankAccount bankAccount = listIterator.next(); //pickup the first surgeon

			System.out.println("Bank Id     : " + bankAccount.getId());
			System.out.println("Bank Owner  : " + bankAccount.getOwner());
			System.out.println("Bank Number : " + bankAccount.getNumber());
			System.out.println("Bank Name   : " + bankAccount.getBankName());
		}
	}

	@Test
	public void testCase4() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<CreditCard> list = dao.getAll("CreditCard4");
		System.out.println(list);

		Iterator<CreditCard> listIterator = list.iterator(); //get iterator for Surgeon

		while (listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			CreditCard creditCard = listIterator.next(); //pickup the first surgeon

			System.out.println("Bank Id     : "+creditCard.getId());
			System.out.println("Bank Owner  : "+creditCard.getOwner());
			System.out.println("Bank Number : "+creditCard.getNumber());
			System.out.println("Card Type   : "+creditCard.getType());
			System.out.println("Expiry Month: "+creditCard.getExpiryMonth());
			System.out.println("Expiry Year : "+creditCard.getExpiryYear());

		}
	}
}
/*

create table BillingDetails4 (
id integer not null,
number varchar(255),
owner varchar(255),
primary key (id))

create table BankAccount4 (
id integer not null,
number varchar(255),
owner varchar(255),

bankName varchar(255),
primary key (id))


 create table CreditCard4 (
 id integer not null,
 number varchar(255),
 owner varchar(255),

 expiryMonth varchar(255),
 expiryYear varchar(255),
 type varchar(255),
 primary key (id))

 */