package com.company.strategy2;
import java.util.Iterator;
import java.util.List;

import com.company.BaseDAOImpl;
import org.junit.jupiter.api.Test;
public class BillingDetailsTest {

	@Test
	public void testCase1() {
		
		BankAccount bankAcc = new BankAccount();
		bankAcc.setOwner("Majrul Ansari");
		bankAcc.setNumber("12345");
		bankAcc.setBankName("ICICI Bank");

		CreditCard creditCard = new CreditCard();
		creditCard.setOwner("Majrul Ansari");
		creditCard.setNumber("412901234567890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2099");

		BaseDAOImpl dao = new BaseDAOImpl();
		dao.mergeAnyObject(bankAcc);
		dao.mergeAnyObject(creditCard);
		
	}
	
	@Test
	public void testCase2() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<BillingDetails> list = dao.getAll("BillingDetails2");
		System.out.println(list);
		Iterator<BillingDetails> listIterator = list.iterator(); //get iterator for Surgeon

		while(listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			BillingDetails billingDetails = listIterator.next(); //pickup the first surgeon

			if(billingDetails instanceof BankAccount) { //find if it is HeartSurgeon
				BankAccount bankAccount = (BankAccount) billingDetails;
				System.out.println("Bank Id     : "+bankAccount.getId());
				System.out.println("Bank Owner  : "+bankAccount.getOwner());
				System.out.println("Bank Number : "+bankAccount.getNumber());
				System.out.println("Bank Name   : "+bankAccount.getBankName());
			}
			else if (billingDetails instanceof CreditCard) {
				CreditCard creditCard = (CreditCard) billingDetails;
				System.out.println("Bank Id     : "+creditCard.getId());
				System.out.println("Bank Owner  : "+creditCard.getOwner());
				System.out.println("Bank Number : "+creditCard.getNumber());
				System.out.println("Card Type   : "+creditCard.getType());
				System.out.println("Expiry Month: "+creditCard.getExpiryMonth());
				System.out.println("Expiry Year : "+creditCard.getExpiryYear());
			}
			System.out.println("------------------");
		}

	}
}
/*

billingdetails2
    PK
	id	number				owner
	11	12345				Majrul <-- referred by BankAccount2's billing_id
	12	412901234567890		Majrul <-- referred by CreditCard2
	13	565656565			Arun
BankAccount2
				(PK+FK)
	bankName	billing_id
	ICICI		11

CreditCard2
	expiryMonth		expiryYear	Type	billing_id
	12				2099		Visa	12

FixedDeposit2
	maturityYear maturityMonth  interestRate	dateOfDeposit   billing_id
	July			2028			4.9			12/Oct/2018		13

create table BillingDetails2 (
	id integer not null,
	number varchar(255),
	owner varchar(255),
	primary key (id)
)

create table BankAccount2 (
	bankName varchar(255),
	billing_id integer not null,
	primary key (billing_id)
)

 create table CreditCard2 (
 expiryMonth varchar(255),
 expiryYear varchar(255),
 type varchar(255),
 billing_id integer not null,
 primary key (billing_id)
 )

alter table BankAccount2
add constraint FKevphqweh66bljn5f234orirnk
foreign key (billing_id) references BillingDetails2

alter table CreditCard2
add constraint FKea8mwahftu59kd9p14ocsf4rb
foreign key (billing_id) references BillingDetails2

select * FROM BILLINGDETAILS2 BD, BANKACCOUNT2 BA WHERE BD.ID = BA.BILLING_ID

select * FROM BILLINGDETAILS2 BD, CREDITCARD2 CC WHERE BD.ID = CC.BILLING_ID


select billingdet0_.id as id1_2_,
billingdet0_.number as number2_2_,
billingdet0_.owner as owner3_2_,
billingdet0_1_.expiryMonth as expirymo1_3_,
billingdet0_1_.expiryYear as expiryye2_3_,
billingdet0_1_.type as type3_3_,
billingdet0_2_.bankName as bankname1_0_,
	case
	when billingdet0_1_.billing_id is not null then 1
	when billingdet0_2_.billing_id is not null then 2
	when billingdet0_.id is not null then 0
	end as clazz_
	from BillingDetails2 billingdet0_
	left outer join CreditCard2 billingdet0_1_
	on billingdet0_.id=billingdet0_1_.billing_id

	left outer join BankAccount2 billingdet0_2_
	on billingdet0_.id=billingdet0_2_.billing_id

 */