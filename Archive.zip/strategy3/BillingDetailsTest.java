package com.company.strategy3;

import java.util.Iterator;
import java.util.List;

import com.company.BaseDAOImpl;
import org.junit.jupiter.api.Test;



public class BillingDetailsTest {

	@Test
	public void testCase1() {
		
		BankAccount bankAcc = new BankAccount();
		bankAcc.setOwner("Majrul Ansari");
		bankAcc.setNumber("12345");
		bankAcc.setBankName("ICICI Bank");

		CreditCard creditCard = new CreditCard();
		creditCard.setOwner("Majrul Ansari");
		creditCard.setNumber("412901234567890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2099");

		BaseDAOImpl dao = new BaseDAOImpl();
		dao.mergeAnyObject(bankAcc);
		dao.mergeAnyObject(creditCard);
	}

	@Test
	public void testCase2() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<BankAccount> list = dao.getAll("BankAccount3");
		System.out.println(list);

		Iterator<BankAccount> listIterator = list.iterator(); //get iterator for Surgeon

		while (listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			BankAccount bankAccount = listIterator.next(); //pickup the first surgeon


			System.out.println("Bank Id     : " + bankAccount.getId());
			System.out.println("Bank Owner  : " + bankAccount.getOwner());
			System.out.println("Bank Number : " + bankAccount.getNumber());
			System.out.println("Bank Name   : " + bankAccount.getBankName());
		}
	}

	@Test
	public void testCase3() {
		BaseDAOImpl dao = new BaseDAOImpl();
		List<CreditCard> list = dao.getAll("CreditCard3");
		System.out.println(list);

		Iterator<CreditCard> listIterator = list.iterator(); //get iterator for Surgeon

		while (listIterator.hasNext()) { //find each (specialized child)surgeon during the loop

			CreditCard creditCard = listIterator.next(); //pickup the first surgeon

			System.out.println("Bank Id     : "+creditCard.getId());
			System.out.println("Bank Owner  : "+creditCard.getOwner());
			System.out.println("Bank Number : "+creditCard.getNumber());
			System.out.println("Card Type   : "+creditCard.getType());
			System.out.println("Expiry Month: "+creditCard.getExpiryMonth());
			System.out.println("Expiry Year : "+creditCard.getExpiryYear());

		}
	}

}
/*


BankAccount3

				<---MappedSuperClass------->
	bankName	id	number				owner
	ICICI		11	12345				Majrul

CreditCard3
										<---MappedSuperClass------->
	expiryMonth		expiryYear	Type	id	number				owner
	12				2099		Visa	12	412901234567890		Majrul

FixedDeposit3
maturityYear maturityMonth  interestRate	dateOfDeposit   	id	number				owner
	July			2028			4.9			12/Oct/2018		14	666777				Arun
 */