package com.java;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.java.layer2.Employee;
import com.java.layer3.EmployeeRepository;
import com.java.layer4.EmployeeService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:employee-jpa-config.xml")


public class EmployeeServiceTest {
	
	@Autowired
	EmployeeService empService;
	
	
	@Autowired
	Employee emp ;
	
	@Test
	public void testAddEmpService() {
		
		emp.setEmployeeNumber(102);
		emp.setEmployeeName("Arun");
		emp.setEmployeeSalary(5000);
		
		empService.addTheEmployeeService(emp);
		
	}
	
	

}
