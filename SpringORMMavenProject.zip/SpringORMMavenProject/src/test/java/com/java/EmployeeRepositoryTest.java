package com.java;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.java.layer2.Employee;
import com.java.layer3.EmployeeRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:employee-jpa-config.xml")

public class EmployeeRepositoryTest {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	Employee employee;
	
	@Test
	void insertEmployeeTest() {
	
		Assertions.assertTrue(employee!=null);
		employee.setEmployeeNumber(101);
		employee.setEmployeeName("Ashish");
		employee.setEmployeeSalary(9999);
		
		Assertions.assertTrue(employeeRepository!=null);
		employeeRepository.insertEmployee(employee);
	}

}
