package com.java.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.java.layer2.Employee;



@Repository
public interface EmployeeRepository {
	
	void insertEmployee(Employee e);
	void updateEmployee(Employee e);
	void deleteEmployee(int empno);
	Employee selectEmployee(int empno);
	List<Employee> selectEmployees();
	
	//List<Employee> selectEmployeesAsPerSal(float sal);
	//void deleteEmployeeByJob(String job);
	//List<Employee> selectEmployeeByJob(String job);
	//List<Employee> selectEmployeeByPin(String job);
	

}
