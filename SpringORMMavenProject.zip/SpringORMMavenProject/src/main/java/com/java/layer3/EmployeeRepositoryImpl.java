package com.java.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.java.layer2.Employee;



@Repository("ormWay")
public class EmployeeRepositoryImpl implements EmployeeRepository {

	
	@PersistenceContext(unitName = "SpringJPA")
	EntityManager entityManager;
	
	@Transactional
	public void insertEmployee(Employee e) {
		System.out.println("EmployeeRepositoryImpl: insertEmployee(Employee) invoked...");
		entityManager.persist(e);

	}

	@Transactional
	public void updateEmployee(Employee e) {
		entityManager.merge(e);

	}

	@Transactional
	public void deleteEmployee(int empno) {
		Employee empObj = entityManager.find(Employee.class, empno);
		entityManager.remove(empObj);

	}

	public Employee selectEmployee(int empno) {
		Employee empObj = entityManager.find(Employee.class, empno);
		return empObj;
	}

	public List<Employee> selectEmployees() {
		Query query = entityManager.createNamedQuery("from Employee");		
		List<Employee> empList = query.getResultList();
		return empList;
	}

}
