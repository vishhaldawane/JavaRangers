create table EMPLOYEE
(
  empno int primary key,
  empname varchar(20),
  salary int
)
..
..
..
..
.



25 tables creation code is reserved here
