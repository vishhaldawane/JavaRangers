package com.java.layer1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Angular a = new Angular();
		a.uiForm();
	}

}
class Pojo { //table + pojo + repo [ repo impl ]
	
	void insertQuery() {
		//...
		System.out.println("Pojo: insertQuery()");
		//....
	}
}

class Repository // plus repository implementations [ entitymanager ]
{
	Pojo p = new Pojo();
	
	void chefStoreThis() {
		//...
		p.insertQuery();
		System.out.println("Repository: chefStoreThis()");
		//....
	}
}
/*----------------------*/


class Service 
{
	Repository r = new Repository();

	void storeService() {
		//..
		r.chefStoreThis();
		System.out.println("Service: storeService()");
		//....
	}
}

// http://ip:8080/SpringProject/storeEmp
class Controller 
{
	Service s = new Service();

	void storeRequest() {
		//...
		s.storeService();
		System.out.println("Controller: storeRequest()");
		//...
	}
}

class Angular 
{
	Controller c = new Controller();

	void uiForm() {
		//...
		c.storeRequest();
		System.out.println("Angular: uiForm()");
		//...
	}
}

/*
 class A {
	
	void fun() {
		//...
		System.out.println("A: fun()");
		//....
	}
}

class B
{
	A a = new A();
	
	void foo() {
		//...
		a.fun();
		System.out.println("B: foo()");
		//....
	}
}
class C 
{
	B b = new B();

	void far() {
		//..
		b.foo();
		System.out.println("C: far()");
		//....
	}
}

class D 
{
	C c = new C();

	void fee() {
		//...
		c.far();
		System.out.println("D: fee()");
		//...
	}
}

class E 
{
	D d = new D();

	void fus() {
		//...
		d.fee();
		System.out.println("E: fus()");
		//...
	}
} 
  
 */


