package com.java.layer4;

import org.springframework.stereotype.Service;

import com.java.layer2.Employee;

@Service
public interface EmployeeService {

	public void addTheEmployeeService(Employee e);
	
}
