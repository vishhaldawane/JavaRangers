package com.java.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.layer2.Employee;
import com.java.layer3.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public void addTheEmployeeService(Employee e) {
		
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		employeeRepository.insertEmployee(e);
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		
	}

}
/*




																	KITCHEN
	TV		TABLE1													  |TV  110  111 113
		Dining   kids								|---------------------------------------
113		   /------------/							|	CRUD
		  /            /					+----------> Repository(3)   ---> POJO(2) --> Table(1)
		 /   UI-Menu  /  Wife				|		|		PizzaRepository, BiryaniRepository, FriedRiceRepository
		/------------- 						|		----------------------------------------
		 	You <--  Controller  --->  Service
					SpringWEB
		
		TABLE2
		TABLE3
		
		
		

*/