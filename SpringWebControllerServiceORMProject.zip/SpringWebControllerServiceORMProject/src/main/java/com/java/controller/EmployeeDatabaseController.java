package com.java.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.entity.Employee;
import com.java.service.EmployeeService;

@RestController

@RequestMapping("/employeesDB")
public class EmployeeDatabaseController {
	

	@Autowired
	EmployeeService empService;
	

	public EmployeeDatabaseController() {
		
		System.out.println("EmployeeDatabaseController() ctor....");
	
	}
	
//	GET     http://localhost:8080/employees/getEmp/101 <-- getting a single object

	
	@PostMapping
	@RequestMapping("/addEmp")
	public String addEmployee(@RequestBody Employee empObj) {
		System.out.println("/addEmp");
		empService.addTheEmployeeService(empObj);
		return "Employee object added successfully.."+empObj.getEmployeeNumber();		
	
	}
	
	@PutMapping
	@RequestMapping("/updateEmp")
	public String updateEmployee(@RequestBody Employee empObj) {
		System.out.println("/updateEmp");
		empService.modifyTheEmployeeService(empObj);
		return "Employee modified : employee number : "+empObj.getEmployeeNumber();
	}
	
	@GetMapping
	@RequestMapping("/getEmp/{eno}")
	public Employee getEmployee(@PathVariable("eno") int x ) {
		System.out.println("/getEmp");	
		Employee foundEmp = empService.findTheEmployeeService(x);
		return foundEmp;
	}

	
	@GetMapping
	@RequestMapping("/deleteEmp/{eno}")
	public String deleteEmployee(@PathVariable("eno") int x ) {
		System.out.println("/deleteEmp");
		
		empService.removeTheEmployeeService(x);
		return "Employee deleted : employee number : "+x;
		
	}

	
	@GetMapping
	@RequestMapping("/getEmps")
	public List<Employee> getEmployees() {
		System.out.println("/getEmps");
		return empService.findAllTheEmployeesService();
	}

}

/*
 
  
  
POST    http://localhost:8080/employees/addEmp/ <-- body of the employee obj
PUT     http://localhost:8080/employees/updateEmp/ <--body of the employee obj
  
DELETE  http://localhost:8080/employees/deleteEmp/101 <-- delete
  
GET     http://localhost:8080/employees/getEmp/101 <-- getting a single object
  
GET     http://localhost:8080/employees/getEmps <-- getting an array list 
  
  
 */
