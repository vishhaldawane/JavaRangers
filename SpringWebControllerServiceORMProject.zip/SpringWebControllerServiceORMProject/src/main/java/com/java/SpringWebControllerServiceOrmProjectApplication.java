package com.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebControllerServiceOrmProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebControllerServiceOrmProjectApplication.class, args);
		System.out.println("Spring Web Controller Service ORM app started....");
	}

}
