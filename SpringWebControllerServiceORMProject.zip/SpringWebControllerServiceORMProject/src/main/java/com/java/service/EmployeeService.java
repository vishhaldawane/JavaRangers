package com.java.service;
import java.util.List;

import org.springframework.stereotype.Service;
import com.java.entity.Employee;
@Service
public interface EmployeeService {
	public void addTheEmployeeService(Employee e); // add -> insert
	public void modifyTheEmployeeService(Employee e); // modify -> update
	public void removeTheEmployeeService(int empno); // remove -> delete
	public Employee findTheEmployeeService(int empno); //find -> select
	public List<Employee> findAllTheEmployeesService(); //findAll -> select
}




/*

				Java Programs
					|
			-------------
			|			|
	Java Application	Web Application
	|						|
	main(String args[])	no main method [ life cycle methods ]								DL		table 1 - EMP TABLE
	|																								|
	test cases																				DL		pojo 2 - Employee.java
	@Test																							|
																							DL		Repo 3 - EmployeeRepository
	Web Application																					|
									[Web Server] <--------> [Servlet Container]		BUSINESS LOGIC->Service 4 - EmployeeService
										| [ ipaddress:port]			|								|
										|							EmployeeProject [ folder ] - getEmp - 101
						---------------------------------			BankingProject
						|		|		|		|		|			InsuranceProject
						client1	client2 .....
						|chrome		|
						web client	|
	request				|		http://ipaddress:8080/EmployeeProject/getEmp/102
						|
	http://ipaddress:8080/EmployeeProject/getEmp/101
	http://ipaddress:8080/BankingProject/getAccount/101
	http://ipaddress:8080/InsuranceProject/getPolicy/101
	<------web server--->
	
	POSTMAN
	|
	http://ipaddress:8080/EmployeeProject/getEmp/101 <-- HTML BUTTON is mapped with this URL - <a href>
	http://ipaddress:8080/EmployeeProject/getEmps
	http://ipaddress:8080/EmployeeProject/addEmp/1122/Jack/6000
	http://ipaddress:8080/EmployeeProject/updateEmp/1122/Jane/6040	
	http://ipaddress:8080/EmployeeProject/delEmp/101
	
	LAYER 5
	@RestController
	class EmployeeController
	{
	
		@Autowired
		EmployeeService empService; <-- SERVICE LAYER 4
		
		@GetMapping
		@RequestMapping("/getEmp/{empno}")
		public Employee getTheEmployeeObject(@RequestParam("empno") int eno) {
			
			Employee empObj = empService.getEmployeeService(eno);
			return empObj; -- GOES TO THE UI LAYER 6
			
		}
	}						
				
Angular - LAYER 6 - ts means "type script" code
 |	|
 | EmployeeService.ts - SERVICE AT ANGULAR SIDE TOO - will talk to the EmployeeController of java
 |
 EmployeeComponent		Employee.ts [ pojo from Angular ]  
  |
------------------
|		|		|
html	css		class
view	style	coding 

class Employee <-- POJO at angular SIDE TOO
{
	employeeNumber : int;
	employeeName :string;
	employeeSalary: int;
}

MACHINE1									MACHINE-x
	|||||||||||									|
	table								html/css/ts <-- USER IS HERE ON UI 	
	|											|
	Pojo									 employee
		|										|
		repo						employee component
			|							|
			service					service
				|					|
				controller <--> angular
						
DIALECTS
---------
HSQLWAY
create table employee
(
    empno int,
    ename varchar(20)
);
    
    
    ORACLEWAY
    create table employee
(
    empno number,
    ename varchar2(20)
);


*/