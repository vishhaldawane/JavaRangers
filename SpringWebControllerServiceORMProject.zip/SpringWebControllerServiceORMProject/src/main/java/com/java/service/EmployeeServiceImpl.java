package com.java.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.entity.Employee;
import com.java.repo.EmployeeRepository;
/*
 * 
 * 
 * 
 * 
 * 
 * 	repo		A			B			C			D		E
 * 
 * 
 * 
 * 
 * 	service			P		Q		R	S
 * 	
 * 
 * 
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public void addTheEmployeeService(Employee e) {
		//some logic here - 20lines code here
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		employeeRepository.insertEmployee(e);
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		//some logic
		// 10 lines code here
	}

	public void modifyTheEmployeeService(Employee e) {
		//some logic here - 20lines code here
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		employeeRepository.updateEmployee(e);
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		//some logic
		// 10 lines code here
				
	}

	public void removeTheEmployeeService(int empno) {
		// TODO Auto-generated method stub
		//some logic here - 20lines code here
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		employeeRepository.deleteEmployee(empno);
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		//some logic
		// 10 lines code here

	}

	public Employee findTheEmployeeService(int empno) {
		// TODO Auto-generated method stub
		//some logic here - 20lines code here
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		Employee employee = employeeRepository.selectEmployee(empno);
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		//some logic
		// 10 lines code here
		return employee;
	}

	public List<Employee> findAllTheEmployeesService() {
		// TODO Auto-generated method stub
		//some logic here - 20lines code here
		System.out.println("EmployeeServiceImpl: Some service pre-logic here...");
		List <Employee> empList = employeeRepository.selectEmployees();
		System.out.println("EmployeeServiceImpl: service post-logic here...to");
		//some logic
		// 10 lines code here

		return empList;
	}

}
/*




																	KITCHEN
	TV		TABLE1													  |TV  110  111 113
		Dining   kids								|---------------------------------------
113		   /------------/							|	CRUD
		  /            /					+----------> Repository(3)   ---> POJO(2) --> Table(1)
		 /   UI-Menu  /  Wife				|		|		PizzaRepository, BiryaniRepository, FriedRiceRepository
		/------------- 						|		----------------------------------------
		 	You <--  Controller  --->  Service
					SpringWEB
		
		TABLE2
		TABLE3
		
		
		
					ForestProject
						|
			--------------------
			|
			jungle
			|
	----------------------------------------
	|			|			|
	river		tree		cave
	|			|			|
	Crocodile	Sparrow		Tiger
	Allegator	Parrot		Lion
	Fish		Monkey		
	Frog
	
					BankingProject
						|
				-------------------
				|
				bank <--main package
				|
		---------------------------------------------------------
1		|2(pojos)	|3			|		|4				|5					6
tbls	entity		repo	repoimpl	service			controller				UI
		|			|			|		|					|	
	BankAccount		BankRepo(i)	|		BankService			BankController
	SavingsAccount		BankRepoImpl(c)	BankServiceImpl		SavingsController
	CurrentAccount	SavingsRepo			SavingsService		CurrentController
	FixedAccount	SavingsRepoImpl		SavingsServiceImpl	FixedController
	
	
*/