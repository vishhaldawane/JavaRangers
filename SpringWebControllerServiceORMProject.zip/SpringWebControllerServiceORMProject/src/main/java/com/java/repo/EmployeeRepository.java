package com.java.repo;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.java.entity.Employee;
@Repository
public interface EmployeeRepository {
	
	void insertEmployee(Employee e); //insert query of the DB
	void updateEmployee(Employee e); //update query
	void deleteEmployee(int empno); //delete
	Employee selectEmployee(int empno); //select
	List<Employee> selectEmployees(); //select
	
}



//List<Employee> selectEmployeesAsPerSal(float sal);
//void deleteEmployeeByJob(String job);
//List<Employee> selectEmployeeByJob(String job);
//List<Employee> selectEmployeeByPin(String job);

