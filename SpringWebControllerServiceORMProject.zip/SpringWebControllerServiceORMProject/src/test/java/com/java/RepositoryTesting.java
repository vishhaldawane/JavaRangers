package com.java;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.java.entity.Employee;
import com.java.repo.EmployeeRepository;

@SpringBootTest
public class RepositoryTesting {
	
	@Autowired
	EmployeeRepository employeeRepo;
	

	@Test
	void testAddEmployee() {
		System.out.println("add test case running....");
		Employee employee = new Employee();
		employee.setEmployeeNumber(110);
		employee.setEmployeeName("Vishhal");
		employee.setEmployeeSalary(99999);
		employeeRepo.insertEmployee(employee);
	}
	
	@Test
	void testUpdateEmployee() {
		System.out.println("update test case running....");
		Employee employee = new Employee();
		employee.setEmployeeNumber(110);
		employee.setEmployeeName("VISHHAL");
		employee.setEmployeeSalary(999990);
		employeeRepo.updateEmployee(employee);
	}
	
	@Test
	void testDeleteEmployee() {
		System.out.println("delete test case running....");
		employeeRepo.deleteEmployee(110);
	}
	
	@Test
	void testGetSingleEmployee() {
		System.out.println("get test case running....");
		Employee empObj = employeeRepo.selectEmployee(102);
		System.out.println("Employee : "+empObj);
	}
	
	@Test
	void testgetAllEmployees() {
		System.out.println("getAll test case running....");
		List<Employee> empList = employeeRepo.selectEmployees();
		/*for (Employee employee : empList) {
			System.out.println("EMPNO : "+employee.getEmployeeNumber());
			System.out.println("ENAME : "+employee.getEmployeeName());
			System.out.println("ESAL  : "+employee.getEmployeeSalary());
			System.out.println("---------------");
		}*/
		
		Iterator<Employee> empIterator = empList.iterator();
		while(empIterator.hasNext()) {
			Employee employee = empIterator.next();
			System.out.println("EMPNO : "+employee.getEmployeeNumber());
			System.out.println("ENAME : "+employee.getEmployeeName());
			System.out.println("ESAL  : "+employee.getEmployeeSalary());
			System.out.println("---------------");
		}
	}

}
/*  TDD - test driven development strategy
 
 	1		table - pizza - VERIFY THE TABLE
 	2		Pojo - pizza - CHECK THE MAPPINGS PROPERLY
 	3		Repo - pizza - STS / intellij test cases for repos
 			
 			
 	4		Service - pizza - STS/intellij test cases for Services
 	5		Controller - pizza - POSTMAN to test it 
			UI - pizza on the table - 


*/