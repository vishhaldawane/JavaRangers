package com.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ServiceTesting {

	@Test
	void test3() {
		System.out.println("add test case SERVICE running....");
	}
	
	@Test
	void test4() {
		System.out.println("update test case SERVICE running....");
	}
	
	@Test
	void test5() {
		System.out.println("delete test case SERVICE running....");
	}
	
	@Test
	void test1() {
		System.out.println("get test case SERVICE running....");
	}
	
	@Test
	void test2() {
		System.out.println("getAll test case SERVICE running....");
	}

}
